



import Foundation
import CoreData

@objc(Category)
public class Category: NSManagedObject {

}
