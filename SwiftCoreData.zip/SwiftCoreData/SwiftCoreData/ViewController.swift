

import UIKit
import CoreData

@available(iOS 10.0, *)
class ViewController: UIViewController {

    var arrCategory = [NSMutableDictionary]()
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        //CALL ONE BY ONE FUNCATION FOR TEST
        
//        self.insertDataInCoreData()
//        self.fetchDataFromCoreData()
//        self.deleteAllRecordFromCoreData()
//        self.deleteOneRecordFromCoreData()
//        self.updateCategory(categoryName: "Jayesh", imagePath: "http://jayesh.com", categoryID: 5) //==This record update in 0 number index
//        self.findAndUpdateOneRecord(categoryName: "Jayesh Poriya", imagePath: "http://jayeshporiya.com", categoryID: 5) //===Which value updated pass that category ID (LIKE:5)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Core Data insert, delete and fetch
    
    func insertDataInCoreData() {

        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let categoryObj = Category(context: context)
        categoryObj.categoryName = "GOOGLE 1"
        categoryObj.imagePath = "http://google1.com"
        categoryObj.categoryID = 1
        // Save the data to coredata
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        
        
        //======THIS IS ALSO WORKING FOR INSERT RECORD===
//        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//        let test: Category = NSEntityDescription.insertNewObject(forEntityName: "Category", into: context) as! Category
//        test.categoryName = "Quad 1"
//        test.imagePath = "This is image url"
//        task.categoryID = 2
//        (UIApplication.shared.delegate as! AppDelegate).saveContext()

    }

    func fetchDataFromCoreData () {

        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetch: NSFetchRequest<Category> = Category.fetchRequest()
        do{
            let searchResult = try context.fetch(fetch)
//            print("searchResult ==>",searchResult)
            
            for result in searchResult as [Category]{
                
//                print("result ==> ",result)
//                print("categoryName ==> ",result.categoryName!)
//                print("imagePath    ==> ",result.imagePath!)
//                print("categoryID    ==> ",result.categoryID)
                
                let tampDict: NSMutableDictionary = NSMutableDictionary()
                tampDict.setValue(result.categoryName, forKey: "CategoryName")
                tampDict.setValue(result.imagePath, forKey: "ImagePath")
                tampDict.setValue(result.categoryID, forKey: "CategoryID")
                
//                print("tampDict ==>",tampDict)
                arrCategory.append(tampDict)
                
            }
            print("arr ==>",arrCategory)
            
//            print("==>",arrCategory[1])
//            print("==>",arrCategory[1].value(forKey: "CategoryID")!)
//            print("==>",arrCategory[1].value(forKey: "CategoryName")!)
//            print("==>",arrCategory[1].value(forKey: "ImagePath")!)



        }
        catch{
            print(error)
        }
    }
    
    func deleteAllRecordFromCoreData(){
        
        //======THIS IS ALSO WORKING===
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        let managedContext = appDelegate.persistentContainer.viewContext
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let DelAllReqVar = NSBatchDeleteRequest(fetchRequest: NSFetchRequest<NSFetchRequestResult>(entityName: "Category"))
        do {
            
            //======THIS IS ALSO WORKING===
//            try managedContext.execute(DelAllReqVar)
            
                try context.execute(DelAllReqVar)
        }
        catch {
            print(error)
        }
    }
    
    func deleteOneRecordFromCoreData () {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetch: NSFetchRequest<Category> = Category.fetchRequest()
        do {
            let searchResult = try context.fetch(fetch)
            for result in searchResult as [Category] {
                
                //====hear check id and delete that record
                if result.categoryID == 3 {
                    context.delete(result)
                    do {
                        try context.save()
                    } catch {
                        print(error)
                    }
                    return
                }
            }
        }
        catch{
            print(error)
        }
    }
    
    func updateCategory (categoryName:String, imagePath:String, categoryID:int_fast16_t) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<Category> = Category.fetchRequest()
        
        do {
            let array_Category = try context.fetch(fetchRequest)
            let result = array_Category[0] //====INDEX = 0
            
            result.setValue(categoryName, forKey: "categoryName")
            result.setValue(imagePath, forKey: "imagePath")
            result.setValue(categoryID, forKey: "categoryID")
            
            //save the context
            do {
                try context.save()
                print("saved!")
            } catch let error as NSError  {
                print("Could not save \(error), \(error.userInfo)")
            } catch {
                
            }
            
        } catch {
            print("Error with request: \(error)")
        }
    }
    
    func findAndUpdateOneRecord (categoryName:String, imagePath:String, categoryID:int_fast16_t) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetch: NSFetchRequest<Category> = Category.fetchRequest()
        do {
            let searchResult = try context.fetch(fetch)
            for result in searchResult as [Category] {
                
                //====hear check id and update  that record
                if result.categoryID == 5 {

                    result.setValue(categoryName, forKey: "categoryName")
                    result.setValue(imagePath, forKey: "imagePath")
                    result.setValue(categoryID, forKey: "categoryID")
                    
                    
                    do {
                        try context.save()
                    } catch {
                        print(error)
                    }
                    return
                }
            }
        }
        catch{
            print(error)
        }
        
    }
    
}

